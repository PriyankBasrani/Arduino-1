#ifndef	_MACHMALLOC_H_
#define	_MACHMALLOC_H_

/* place holder so platforms may add malloc.h extensions */

#endif	/* _MACHMALLOC_H_ */


